package runner;



import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith;
import org.junit.runner.notification.Failure;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import stepDefinitions.Action;


@RunWith(Cucumber.class)
@CucumberOptions(strict = false,
		plugin = {"pretty","html:target/cucumberHtml","junit:target/cucumber-reports/CucumberJunit.xml","json:target/cucumber-reports/CucumberJson.json","com.cucumber.listener.ExtentCucumberFormatter:TestReport/report.html"},
		features = {"features"},
		glue = {"stepDefinitions"},
		monochrome = true,
		tags = {"@ESS1,@ESS2,@ESS3,@ESS4,@ESS5"}
		)


public class RunCukesTest{
	public static void main(String[] args) {									
	      Result result = JUnitCore.runClasses(Action.class);					
				for (Failure failure : result.getFailures()) {							
	         System.out.println(failure.toString());					
	      }		
	      System.out.println("Result=="+result.wasSuccessful());							
	   }		
}


