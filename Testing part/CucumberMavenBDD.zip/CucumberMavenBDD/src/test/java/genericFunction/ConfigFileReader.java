package genericFunction;

import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ConfigFileReader {
	Properties properties = new Properties();
	InputStream inputStream;

	public String getReportConfigPath() throws IOException {
		String propFileName = System.getProperty("user.dir") + "\\src\\test\\resources\\config\\Config.properties";
		FileReader inputStream = new FileReader(propFileName);
		properties.load(inputStream);
		String reportConfigPath = properties.getProperty("reportConfigPath");
		if (reportConfigPath != null)
			return reportConfigPath;
		else
			throw new RuntimeException(
					"Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");
	}
}
