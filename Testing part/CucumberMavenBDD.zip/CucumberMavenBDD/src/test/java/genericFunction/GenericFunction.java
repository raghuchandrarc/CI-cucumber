package genericFunction;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GenericFunction { 
	
	public LinkedHashMap<String, String> getRowDataHM(String filePath, String workBookName, String sheetName, int rowindex) throws Exception {
		FileInputStream file = new FileInputStream(new File(filePath+"\\"+workBookName+".xlsx"));
		XSSFWorkbook book = new XSSFWorkbook(file);
		XSSFSheet sheet = book.getSheet(sheetName);
		XSSFRow row = sheet.getRow(rowindex);
		XSSFRow headerRow = sheet.getRow(0);
		LinkedHashMap<String, String> data = new LinkedHashMap<String, String>();
		int firstCell = headerRow.getFirstCellNum();
		int lastCell = headerRow.getLastCellNum();
		XSSFCell cell1 = headerRow.getCell(firstCell);
		XSSFCell cell2 = row.getCell(firstCell);
		DataFormatter formatter = new DataFormatter();
		for(int i=firstCell; i < lastCell; i++) {
			cell1 = headerRow.getCell(i);
			cell2 = row.getCell(i);
			String headerValue = cell1.getStringCellValue();
			String fieldValue;
			
			if(cell2 == null) {
				fieldValue="";
			}
			else {
				 fieldValue =  formatter.formatCellValue(cell2);
			}
			if(cell2.getCellType()==Cell.CELL_TYPE_STRING){
				 fieldValue =  formatter.formatCellValue(cell2);
				fieldValue = cell2.getStringCellValue();
			}
			if(cell2.getCellType()==Cell.CELL_TYPE_BLANK){
				fieldValue="";
			//	fieldValue = cell2.getStringCellValue();
			}
		 if(cell2.getCellType()==Cell.CELL_TYPE_NUMERIC )
			 {
			    fieldValue =  formatter.formatCellValue(cell2);
				fieldValue = String.valueOf(cell2.getNumericCellValue());
			}
			data.put(headerValue, fieldValue);
		}
		book.close();
		return data;
	}
	
	public List<LinkedHashMap<String, String>> getTestDataListByScenario(String filePath, String workBookName, String sheetName, String scenarioName) throws Exception {
		FileInputStream file = new FileInputStream(new File(filePath+"\\"+workBookName+".xlsx"));
		XSSFWorkbook book = new XSSFWorkbook(file);
		XSSFSheet sheet = book.getSheet(sheetName);
		List<LinkedHashMap<String, String>> data = new ArrayList<LinkedHashMap<String, String>>();
		
		int totalRows = sheet.getPhysicalNumberOfRows();
		for(int i = 0; i < totalRows; i++) {
			XSSFRow row = sheet.getRow(i);
			XSSFCell cell = row.getCell(0);
			
			if(cell.getStringCellValue().equalsIgnoreCase(scenarioName)) {
				data.add(getRowDataHM(filePath, workBookName, sheetName, i));
				break;
			}
		}
		book.close();
		return data;
	}
	

	 public boolean setCellData(String path, String sheetName, String colName, int rowNum, String Testdata) {
        try {
               FileInputStream fis = new FileInputStream(path);
               XSSFWorkbook workbook = new XSSFWorkbook(fis);

               if (rowNum <= 0)
                     return false;

               int index = workbook.getSheetIndex(sheetName);
               int colNum = -1;
               if (index == -1)
                     return false;

               XSSFSheet sheet = workbook.getSheetAt(index);

               XSSFRow row = sheet.getRow(0);
               for (int i = 0; i < row.getLastCellNum(); i++) {
                     // System.out.println(row.getCell(i).getStringCellValue().trim());
                     if (row.getCell(i).getStringCellValue().trim().equals(colName))
                            colNum = i;
                     System.out.println("Inside xl "+path+" --"+sheetName+"-- "+colName+"-- " +rowNum+" --"+Testdata+"---"+colNum+"");
                    
               }
             

               sheet.autoSizeColumn(colNum);
               row = sheet.getRow(rowNum - 1);
               if (row == null)
                     row = sheet.createRow(rowNum - 1);

               XSSFCell cell = row.getCell(colNum);
               if (cell == null)
                     cell = row.createCell(colNum);

               System.out.println("Inside xl sheet "+path+" --"+sheetName+"-- "+colName+"-- " +rowNum+" --"+Testdata);
               cell.setCellValue(Testdata);

               FileOutputStream fileOut = new FileOutputStream(path);

               workbook.write(fileOut);

               fileOut.close();

        } catch (Exception e) {
               e.printStackTrace();
               return false;
        }
        return true;
 }

     public static void main(String args[]) throws Exception {
         GenericFunction fn = new GenericFunction();
         String filePath = System.getProperty("user.dir") + "\\TestDataFiles\\TestData.xlsx";

         fn.setCellData(filePath, "Sheet1", "Empolyee", 2, "emp-152393990");
  }
	

}
