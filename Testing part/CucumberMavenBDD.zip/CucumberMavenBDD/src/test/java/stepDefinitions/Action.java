package stepDefinitions;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.junit.Rule;
import org.junit.rules.ErrorCollector;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

import java.util.List;

import genericFunction.GenericFunction;
import genericFunction.Property;

import static org.hamcrest.Matchers.equalTo;

import org.junit.rules.ErrorCollector;

public class Action {
	public static WebDriver driver;
	public static LinkedHashMap<String, String> testdataMap;
	public static String scenarioName;
	public static String description;
	public static int rownum = 1;
	public static final String nodeURL = "http://10.44.10.105:5566/wd/hub";

	// ExtentReports extent = new ExtentReports();

	// ExtentTest test = extent.createTest("TestCaseID", "");

	@Rule
	public ErrorCollector collector = new ErrorCollector();

	GenericFunction gf = new GenericFunction();

	public int existsElement(String element, Property locator) throws Exception {
		int findFlag = 0;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement Getelement = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(Getelement));
			findFlag = 1;
			System.out.println(element + " is present ");

		} catch (Throwable t) {
			System.out.println("Error is ----" + t.getMessage());
			// return false;
			findFlag = 0;
			// collector.addError(e.getMessage());
			// collector.addError(e);
			// collector.addError(t);
			// collector.checkThat(findFlag, equalTo(1));
			System.out.println("error collector");

		}

		return findFlag;
		// collector.checkThat(1,
		// collector.checkThat(findFlag, equalTo(1));

	}

	@SuppressWarnings("deprecation")
	public void openBrowser() throws Throwable {
		// runGrid();
		runScripts();

		// for grid setup

		/*
		 * System.out.println(" Executing on CHROME"); DesiredCapabilities
		 * returnCapabilities = DesiredCapabilities.chrome(); driver = new
		 * RemoteWebDriver(new URL(nodeURL), returnCapabilities);
		 * driver.manage().window().maximize();
		 */

	}

	public void runScripts() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();

	}

	public void runGrid() throws MalformedURLException {
		System.out.println(" Executing on CHROME");
		DesiredCapabilities returnCapabilities = DesiredCapabilities.chrome();
		driver = new RemoteWebDriver(new URL(nodeURL), returnCapabilities);
		driver.manage().window().maximize();
	}

	public void navigateToUrl(String element) throws Exception {
		driver.get(element);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	public void clickElement(String element, Property locator) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement Getelement = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(Getelement));
			driver.findElement(locator.getLocator(element)).click();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void sendKeys(String element, Property locator, String value) throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement Getelement = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(Getelement));
			Getelement.sendKeys(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void ClearAndSendKeys(String element, Property locator, String value) throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement Getelement = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(Getelement));
			Getelement.clear();
			Getelement.sendKeys(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectByText(String element, Property locator, String value) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));

		Select select = new Select(Getelement);
		try {
			select.selectByVisibleText(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectByValue(String element, Property locator, String value) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		Select select = new Select(Getelement);
		try {
			select.selectByValue(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void selectByIndex(String element, Property locator, int value) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		Select select = new Select(Getelement);
		try {
			select.selectByIndex(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void acceptAlert() throws Exception {
		Thread.sleep(2000);

		driver.switchTo().alert().accept();
	}

	public void dismissAlert() throws Exception {
		Thread.sleep(2000);

		driver.switchTo().alert().dismiss();
	}

	public void switchToFrame(String frameID) throws Exception {
		Thread.sleep(2000);

		try {
			driver.switchTo().frame(frameID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void dragAndDrop(String source, String destination, Property locator) throws Exception {
		Thread.sleep(3000);

		Actions action = new Actions(driver);
		WebElement sourceValue = driver.findElement(locator.getLocator(source));
		WebElement target = driver.findElement(locator.getLocator(destination));
		try {
			action.dragAndDrop(sourceValue, target).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void mouseHover(String element, Property locator) throws Exception {
		Thread.sleep(3000);

		Actions action = new Actions(driver);
		try {
			action.moveToElement(driver.findElement(locator.getLocator(element))).build().perform();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public void uploadFile(String location) throws Exception {
		Thread.sleep(3000);

		try {
			Runtime.getRuntime().exec(location);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public String getText(String element, Property locator) throws Exception {
		String text = null;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		try {
			text = Getelement.getText();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return text;
	}

	/**
	 * @param element
	 * @param locator
	 * @param value
	 * @throws Exception
	 */
	public void Verify(String element, Property locator, String value) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement ActualText = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(ActualText));
			String GetActualText = ActualText.getText();
			if (GetActualText.equals(value)) {
				System.out.println("Value is matched");
			} else {
				System.out.println("Value is Notmatched");

			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public void readexceldata(String ScenarioName, String SheetName) throws Exception {
		String TestData = System.getProperty("user.dir") + "\\TestDataFiles";
		testdataMap = gf.getTestDataListByScenario(TestData, "TestData", SheetName, ScenarioName).get(rownum - 1);
		System.out.println(testdataMap);
		scenarioName = testdataMap.get("Scenario");
		description = testdataMap.get("Description");
	}

	public boolean setCellData(String path, String sheetName, String colName, String Testdata) {
		try {
			FileInputStream fis = new FileInputStream(path);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			int rowNum = 2;

			if (rowNum <= 0)
				return false;

			int index = workbook.getSheetIndex(sheetName);
			int colNum = -1;
			if (index == -1)
				return false;

			XSSFSheet sheet = workbook.getSheetAt(index);

			XSSFRow row = sheet.getRow(0);
			for (int i = 0; i < row.getLastCellNum(); i++) {
				// System.out.println(row.getCell(i).getStringCellValue().trim());
				if (row.getCell(i).getStringCellValue().trim().equals(colName))
					colNum = i;
				System.out.println("Inside xl " + path + " --" + sheetName + "-- " + colName + "-- " + rowNum + " --"
						+ Testdata + "---" + colNum + "");

			}

			// sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);

			XSSFCell cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);

			System.out.println("Inside xl sheet " + path + " --" + sheetName + "-- " + colName + "-- " + rowNum + " --"
					+ Testdata);
			cell.setCellValue(Testdata);

			FileOutputStream fileOut = new FileOutputStream(path);

			workbook.write(fileOut);

			fileOut.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	public void closeBrowser() {
		driver.quit();
	}

	public void ClickLinkTextInWebTable(String element, Property locator, String value, int reqCol, String linkText)
			throws Exception {
		int row = 0;
		try {
			//WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement mytable = driver.findElement(locator.getLocator(element));
			//wait.until(ExpectedConditions.visibilityOf(mytable));
			List<WebElement> rowstable = mytable.findElements(By.tagName("tr"));

			int rows_count = rowstable.size();

			for (row = 0; row < rows_count; row++) {
				List<WebElement> colstable = rowstable.get(row).findElements(By.tagName("td"));
				int cols_count = colstable.size();
				for (int col = 0; col < cols_count; col++) {
					String Columnsrow = colstable.get(col).getText();

					if (Columnsrow.equals(value)) {
						System.out.println("Value is matched in WebTable");
						highlighElement(driver, rowstable.get(row)
								.findElement(By.xpath("td[" + reqCol + "]/a[contains(text(), '" + linkText + "')]")));
			rowstable.get(row).findElement(By.xpath("td[" + reqCol + "]/a[contains(text(), '" + linkText + "')]"))
								.click();
						System.out.println(linkText + " link is clicked in WebTable");
						break;
					}
					

				}

				
			}

		} catch (NoSuchElementException e) {

			System.out.println(e.getMessage());
			System.out.println(linkText + " link is not found in WebTable for text " + value);
		}
		
	}

	public void VerifyTextInWebTable(String element, Property locator, String value, int reqCol, String expCellText)
			throws Exception {
		int row = 0;
		try {
			//WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement mytable = driver.findElement(locator.getLocator(element));
			//wait.until(ExpectedConditions.visibilityOf(mytable));
			List<WebElement> rowstable = mytable.findElements(By.tagName("tr"));

			int rows_count = rowstable.size();

			for (row = 0; row < rows_count; row++) {
				List<WebElement> colstable = rowstable.get(row).findElements(By.tagName("td"));
				int cols_count = colstable.size();
				for (int col = 0; col < cols_count; col++) {
					String Columnsrow = colstable.get(col).getText();

					if (Columnsrow.equals(value)) {
						System.out.println("Value is matched in WebTable");
						highlighElement(driver,rowstable.get(row).findElement(By.xpath("td["+reqCol+"]")));
							System.out.println(expCellText + " text is verified in WebTable");
							break;
					}

				
				}
			}
		} catch (NoSuchElementException e) {

			System.out.println(e.getMessage());
		}
	}

	public void VerifyNoTextInWebTable(String element, Property locator, String value, int reqCol, String expCellText)
			throws Exception {
		int row = 0;
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement mytable = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(mytable));
			List<WebElement> rowstable = mytable.findElements(By.tagName("tr"));

			int rows_count = rowstable.size();

			for (row = 0; row < rows_count; row++) {
				List<WebElement> colstable = rowstable.get(row).findElements(By.tagName("td"));
				int cols_count = colstable.size();
				for (int col = 0; col < cols_count; col++) {
					String Columnsrow = colstable.get(col).getText();
					if (Columnsrow.equals(value)) {
						System.out.println("Value is NOt matched in WebTable");
						highlighElement(driver, rowstable.get(row));
						highlighElement(driver, rowstable.get(row).findElement(By.xpath("td[" + reqCol + "]")));
							System.out.println(expCellText + " text is verified in WebTable");
							break;
					}

				}
			}
		} catch (NoSuchElementException e) {

			System.out.println(e.getMessage());
		}

		/*if (foundflag == 1) {
			System.out.println(expCellText + " celltext is found in WebTable for text " + value + "  Failed");
		} else {
			System.out.println(expCellText + " celltext is not found in WebTable for text " + value + " Passed");
		}*/

	}

	public String CreateRandomNumber(String name) {

		int rand_int1 = ThreadLocalRandom.current().nextInt();
		String rndName = name + Integer.toString(rand_int1);
		return rndName;

	}
	 public static void highlighElement(WebDriver driver, WebElement element){
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		 }

	

}
