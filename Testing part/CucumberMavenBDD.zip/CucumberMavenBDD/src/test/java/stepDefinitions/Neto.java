package stepDefinitions;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import genericFunction.GenericFunction;
import genericFunction.Property;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.ErrorCollector;
//import org.junit.After;
import static org.hamcrest.Matchers.equalTo;
import static org.testng.Assert.assertEquals;

public class Neto extends Action {
	
	
	public Property GetObject = new Property(
			System.getProperty("user.dir") + "\\ObjectMapping\\ObjectRepository.properties");
	
	GenericFunction fn = new GenericFunction();
    String filePath = System.getProperty("user.dir") + "\\TestDataFiles\\TestData.xlsx";
    String employeeName;

	@Given("^test data is read from excel \"([^\"]*)\" under \"([^\"]*)\"$")
	public void test_data_is_read_from_excel_under(String scenarioName, String sheetName) throws Throwable {

		System.out.println("Scenarion Name-->" + scenarioName);
		System.out.println("Test Data-->" + sheetName);
		readexceldata(scenarioName, sheetName);
	}
	
	@Given("^test data is write to excel \"([^\"]*)\" under \"([^\"]*)\"$")
	public void test_data_is_write_to_excel_under(String arg1, String arg2) throws Throwable {
		String employeeName = CreateRandomNumber("emp");
		setCellData(filePath, "Sheet1", "Employee", employeeName);
	}


	@When("^User opens browser$")
	public void user_opens_browser() throws Throwable {
			openBrowser();
	}

	@And("^user enters the username$")
	public void user_enters_the_username() throws Throwable {
		sendKeys("username", GetObject, testdataMap.get("Username"));
	}

	@And("^navigate url$")
	public void navigate_to_url() throws Throwable {
		navigateToUrl(testdataMap.get("URL"));
	}

	@And("^user enters the password$")
	public void user_enters_the_password() throws Throwable {
		sendKeys("password", GetObject, testdataMap.get("Password"));
	}

	@Then("^user clicks on Login$")
	public void user_clicks_on_Login() throws Throwable {
		clickElement("signin", GetObject);
	}

	@And("^the verify the title$")
	public void the_verify_the_title() throws Throwable {
		Verify("VerifyTitle", GetObject, testdataMap.get("Title"));

	}
	@And("^the verify the Pricing$")
	public void the_verify_the_Pricing() throws Throwable {
		Verify("VerifyPricing", GetObject, testdataMap.get("Price"));

	}
	@Then("^user clicks on Pricing$")
	public void user_clicks_on_Pricing() throws Throwable {
		clickElement("pricing", GetObject);
	}

	@Then("^user quits the browser$")
	public void user_quits_the_browser() throws Throwable {
		closeBrowser();
	}
	
	@Then("^verify text \"([^\"]*)\" exist$")
	public void verify_text_exist(String arg1) throws Throwable {	    
		int res= existsElement( "EmployeeManagement" , GetObject);
		
	}
	
	@When("^Add Employee$")
	public void add_Employee() throws Throwable {
		String employeeName = CreateRandomNumber("emp");	
		System.out.println("Employee Name before "+ employeeName);		
		sendKeys( "empName", GetObject, employeeName  );
		sendKeys( "empDesignation", GetObject, "Engineer Software"  );
		sendKeys( "location", GetObject, "India"  );
		clickElement("save", GetObject);	
		setCellData(filePath, "Sheet1", "Employee", employeeName);
		System.out.println("Employee Name After "+ employeeName);
	}
		

	@Then("^Verify Employee$")
	public void verify_Employee() throws Throwable {		
		VerifyTextInWebTable("empList", GetObject, testdataMap.get("Employee"),3,"Devops Engineer") ;	
		
	}	
	
	@When("^Update Employee$")
	public void update_Employee() throws Throwable {
		ClickLinkTextInWebTable("empList", GetObject, testdataMap.get("Employee"),5,"Edit") ;	   
		ClearAndSendKeys("empDesignation", GetObject, "Devops Engineer");		
		clickElement("save", GetObject);	
	}
		
	@When("^Delete Employee$")
	public void delete_Employee() throws Throwable {
		ClickLinkTextInWebTable("empList", GetObject, testdataMap.get("Employee"),5,"Delete") ;		
	}

	@Then("^Verify Employee not listed$")
	public void verify_Employee_not_listed() throws Throwable {
		VerifyNoTextInWebTable("empList", GetObject, testdataMap.get("Employee"),2,testdataMap.get("Employee")) ;
	}
	
	@Then("^Close Browser$")
	public void close_Browser() throws Throwable {	
		Thread.sleep(5000);
		closeBrowser();	     	
		
	}
	@When("^fail Test$")
	public void fail_Test() throws Throwable {
		String actual = "abcd";
		String expected = "abc";
		assertEquals(actual, expected);
	}
	
	



	
}
