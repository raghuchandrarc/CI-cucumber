package runner;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;


@RunWith(Cucumber.class)
@CucumberOptions(strict = false,
		plugin = {"pretty","html:target/cucumberHtml","junit:target/cucumber-reports/CucumberJunit.xml","json:target/cucumber-reports/CucumberJson.json", "html:target/site/cucumber-pretty"},
		features = {"features"},
		glue = {"stepDefinitions"},
		monochrome = true,
		//tags = {"@Neto1,@NetoPricing1,@Neto2,@NetoPricing2"}
				tags = {"@Neto1,@NetoPricing1"}
		)


public class RunCukesTest{


}


