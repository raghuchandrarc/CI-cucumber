package stepDefinitions;

import org.testng.Assert;

import com.aventstack.extentreports.Status;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import genericFunction.Property;

public class Neto extends Action {

	public Property GetObject = new Property(
			System.getProperty("user.dir") + "\\ObjectMapping\\ObjectRepository.properties");

	@Given("^test data is read from excel \"([^\"]*)\" under \"([^\"]*)\"$")
	public void test_data_is_read_from_excel_under(String scenarioName, String sheetName) throws Throwable {

		System.out.println("Scenarion Name-->" + scenarioName);
		System.out.println("Test Data-->" + sheetName);
		readexceldata(scenarioName, sheetName);
		Thread.sleep(3000);
		//setReport(scenarioName, description);
	}

	@When("^User opens browser$")
	public void user_opens_browser() throws Throwable {
		try {
			openBrowser();
		} catch (Exception e) {
			e.getMessage();
		}

	}

	@And("^user enters the username$")
	public void user_enters_the_username() throws Throwable {
		sendKeys("username", GetObject, testdataMap.get("Username"));
	}

	@And("^navigate url$")
	public void navigate_to_url() throws Throwable {
		navigateToUrl(testdataMap.get("URL"));
	}

	@And("^user enters the password$")
	public void user_enters_the_password() throws Throwable {
		sendKeys("password", GetObject, testdataMap.get("Password"));
	}

	@Then("^user clicks on Login$")
	public void user_clicks_on_Login() throws Throwable {
		clickElement("signin", GetObject);
	}

	@And("^the verify the title$")
	public void the_verify_the_title() throws Throwable {
		Verify("VerifyTitle", GetObject, testdataMap.get("Title"));

	}
	@And("^the verify the Pricing$")
	public void the_verify_the_Pricing() throws Throwable {
		Verify("VerifyPricing", GetObject, testdataMap.get("Price"));

	}
	
	
	@Then("^user clicks on Pricing$")
	public void user_clicks_on_Pricing() throws Throwable {
		clickElement("pricing", GetObject);
	}
	
	@Then("^user clicks on PricingFail$")
	public void user_clicks_on_PricingFail() throws Throwable {
		clickElement("pricingFail", GetObject);
	}


	@Then("^user quits the browser$")
	public void user_quits_the_browser() throws Throwable {
		closeBrowser();
	}


	

	

}
