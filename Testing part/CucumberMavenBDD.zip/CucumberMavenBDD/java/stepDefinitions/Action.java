package stepDefinitions;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import cucumber.api.java.After;
import genericFunction.Property;
import genericFunction.GenericFunction;

public class Action {
	public static WebDriver driver;
	public static LinkedHashMap<String, String> testdataMap;
	public static String scenarioName;
	public static String description;
	public static int rownum=1;
	
	public static String TestResults = System.getProperty("user.dir") + "\\TestResults\\TestRunResults.html";
	// create ExtentReports and attach reporter(s)
	ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter(TestResults);
	ExtentReports extent = new ExtentReports();
	public static ExtentTest test;

	@After
	public void TestCaseController() {
		extent.attachReporter(htmlReporter);
		extent.flush();
	}
	public static String capture(WebDriver driver, String screenShotName) throws IOException {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File source = ts.getScreenshotAs(OutputType.FILE);
		String dest = System.getProperty("user.dir") + "\\TestResults\\Screenshot\\" + screenShotName + ".png";
		File destination = new File(dest);
		//FileUtils.copyFile(source, destination);

		return dest;
	}
	
	GenericFunction gf = new GenericFunction();
	
	
	public void openBrowser() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}
	
	public void navigateToUrl(String element) throws Exception {
		driver.get(element);
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	public void clickElement(String element, Property locator) throws Throwable {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement Getelement = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(Getelement));
			driver.findElement(locator.getLocator(element)).click();
			//test.log(Status.PASS, element);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			test.log(Status.FAIL, element);
			String screenShot = capture(driver, "FAIL");
			test.addScreenCaptureFromPath(screenShot);
		
		}
	}
	
	public void sendKeys(String element, Property locator, String value) throws Exception {

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement Getelement = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(Getelement));
			Getelement.sendKeys(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectByText(String element, Property locator, String value) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		
		Select select = new Select(Getelement);
		try {
			select.selectByVisibleText(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectByValue(String element, Property locator, String value) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		Select select = new Select(Getelement);
		try {
			select.selectByValue(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void selectByIndex(String element, Property locator, int value) throws Exception {
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		Select select = new Select(Getelement);
		try {
			select.selectByIndex(value);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void acceptAlert() throws Exception {
		Thread.sleep(2000);
		
		driver.switchTo().alert().accept();
	}
	
	public void dismissAlert() throws Exception {
		Thread.sleep(2000);
		
		driver.switchTo().alert().dismiss();
	}
	
	public void switchToFrame(String frameID) throws Exception {
		Thread.sleep(2000);
		
		try {
			driver.switchTo().frame(frameID);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void dragAndDrop(String source, String destination, Property locator) throws Exception{
		Thread.sleep(3000);
		
		Actions action = new Actions(driver);
		WebElement sourceValue = driver.findElement(locator.getLocator(source));
		WebElement target = driver.findElement(locator.getLocator(destination));
		try {
			action.dragAndDrop(sourceValue, target).build().perform();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void mouseHover(String element, Property locator) throws Exception {
		Thread.sleep(3000);
		
		Actions action = new Actions(driver);
		try {
			action.moveToElement(driver.findElement(locator.getLocator(element))).build().perform();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public void uploadFile(String location) throws Exception {
		Thread.sleep(3000);
		
		try {
			Runtime.getRuntime().exec(location);
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	public String getText(String element, Property locator) throws Exception {
		String text = null;
		WebDriverWait wait = new WebDriverWait(driver, 30);
		WebElement Getelement = driver.findElement(locator.getLocator(element));
		wait.until(ExpectedConditions.visibilityOf(Getelement));
		try {
			text = Getelement.getText();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return text;
	}
	
	public void Verify(String element, Property locator, String value) throws Exception {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			WebElement ActualText = driver.findElement(locator.getLocator(element));
			wait.until(ExpectedConditions.visibilityOf(ActualText));
			String GetActualText= ActualText.getText();
			if(GetActualText.equals(value)) {
				System.out.println("Value is matched");
			}
			else {
				System.out.println("Value is Notmatched");
				
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	
	public void readexceldata(String ScenarioName, String SheetName) throws Exception {
		String TestData=System.getProperty("user.dir")+"\\TestDataFiles";
		testdataMap = gf.getTestDataListByScenario(TestData, "TestData", SheetName, ScenarioName).get(rownum-1);
		System.out.println(testdataMap);
		scenarioName = testdataMap.get("Scenario");
		description = testdataMap.get("Description");
	}
	
	/*public void setReport(String Scenario, String Description) {
		String TestReport=System.getProperty("user.dir")+"\\TestReport\\ExtentReport.html";
		htmlReport = new ExtentHtmlReporter(TestReport); 
		extent = new ExtentReports();
		extent.attachReporter(htmlReport);
		test = extent.createTest(Scenario, Description);
	}*/
	
	
	
	
	public void closeBrowser() {
		driver.quit();
	}

}
