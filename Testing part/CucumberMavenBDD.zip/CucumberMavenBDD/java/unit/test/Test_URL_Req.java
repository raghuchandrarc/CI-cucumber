package unit.test;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.poi.util.SystemOutLogger;





public class Test_URL_Req {
public static void main(String[] args) {
	
	HttpHost targetHost = new HttpHost("http://10.44.10.105", 8084, "http");
	CredentialsProvider credsProvider = new BasicCredentialsProvider();
	credsProvider.setCredentials(AuthScope.ANY, 
	  new UsernamePasswordCredentials("admin", "admin123"));

	AuthCache authCache = new BasicAuthCache();
	authCache.put(targetHost, new BasicScheme());

	// Add AuthCache to the execution context
	final HttpClientContext context = HttpClientContext.create();
	context.setCredentialsProvider(credsProvider);
	context.setAuthCache(authCache);
	System.out.println("c");
}
	
	
	


}
